#!/usr/bin/env python 

__author__  = 'Mario Krenn'
__version__ = 'v0.1.2'

from .selfies_fcts import encoder, decoder


